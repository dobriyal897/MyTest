/* Create the database TEST_DB before running this script */
USE TEST_DB;
create table TEST_TABLE (TEST_COL1 varchar(20), TEST_COL2 Datetime not null, TEST_COL3 bit, TEST_COL4 Float)
go
insert into TEST_TABLE(TEST_COL1,TEST_COL2,TEST_COL3,TEST_COL4)
values('test1','2023-08-15 00:12:13.000',1,123.45), ('test2','2023-08-15 00:13:13.000',2,121.45),('test3','2023-08-16',3,120.45),('test4','2023-08-11',2,121.40),('test5','2023-08-12',0,121.13)
go
select * from Test_Table
go

