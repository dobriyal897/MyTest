﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;

namespace MyTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Execute the sql scripts provided in local before running the code
        //Method to load the data from database table into the List and sort the list by Test_col2 datetime ascending
       public async Task<List<Test_Table>> GetListOfInstances()
        {
            List<Test_Table> tblinstances = new List<Test_Table>();
            Test_Table_dalDataContext dbcontext = new Test_Table_dalDataContext();
            var instances = await Task.Run(()=>(from c in dbcontext.TEST_TABLEs
                     orderby c.TEST_COL2 ascending
                     select c).ToList());
            foreach(TEST_TABLE tbl in instances)
            {
                Test_Table test_tbls = new Test_Table()
                {
                    TEST_COL1 = tbl.TEST_COL1,
                    TEST_COL2 = tbl.TEST_COL2,
                    TEST_COL3 = tbl.TEST_COL3,
                    TEST_COL4 = tbl.TEST_COL4

                };
                tblinstances.Add(test_tbls);
                
            }
            if(tblinstances!=null)
            {
                return tblinstances;
            }
                    
            return null;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Test_Table> instances = GetListOfInstances().Result;
            grdTestTable.DataSource = instances;
            
           
           
        }
    }
}
