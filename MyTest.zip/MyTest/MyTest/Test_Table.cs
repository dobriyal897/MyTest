﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlTypes;
using System.ComponentModel.DataAnnotations;
namespace MyTest
{
    public class Test_Table
    {
        [MaxLength(20)]
        public SqlString TEST_COL1 { set; get; }
        public SqlDateTime TEST_COL2 { set; get; }
        [MaxLength(1)]
        public SqlBoolean ? TEST_COL3 { set; get; }
        public double ? TEST_COL4 { set; get; }

    }
}
